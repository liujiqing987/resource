//
//  c_agreement_service.h
//  DreaminaAgreement
//
//  Created by ByteDance on 2024/7/25.
//

#ifndef c_agreement_service_h
#define c_agreement_service_h

#include <stdio.h>
#include <stdint.h>


#ifdef __cplusplus
extern "C" {
#endif

typedef void (*log_callback)(int, const char*);

// 获取当前SDK的草稿版本号
const char * draft_version();
// 设置alog回调
void set_log_callback(log_callback cb);
// 即梦协议 -> 服务端Flow协议
const char * convert_draft_to_server_flow(const char * draft_json, int32_t *code);
// 即梦协议(带断点调试) -> 服务端Flow协议
const char * convert_stopid_draft_to_server_flow(const char * draft_json, const char * stopid, int32_t *code);
// 草稿升级
const char * draft_upgrade(const char * draft_json, int32_t *code);
// 草稿降级
const char * draft_downgrade(const char * draft_json, int32_t *code);
// 草稿资源获取
const char * fetch_resources_from_draft(const char * draft_json);

#ifdef __cplusplus
}
#endif

#endif /* c_agreement_service_h */
